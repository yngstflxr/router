import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import { Root } from './components/Root/Root'
import { ErrorPage404 } from './components/ErrorPage404/ErrorPage404';
import fvckinDZ, {loader as rootLoader} from './routes/fvckinDZ/fvckinDZ';
import { noteBOOK } from './routes/noteBOOK/noteBOOK';

const kepasa = createBrowserRouter([
  {
    path: '/',
    element: <Root />,
    errorElement: <ErrorPage404 />,
    children: [
      {
        path: 'fvckinDZ',
        element: <fvckinDZ />,
        loader: rootLoader,
      },
      {
        path: 'NoteBOOK',
        element: <noteBOOK />,
      }
    ]
  },
]);

function App() {
  return <RouterProvider router={kepasa} />
}
export default App
