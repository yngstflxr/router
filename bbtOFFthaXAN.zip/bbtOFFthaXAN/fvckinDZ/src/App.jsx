import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import { Root } from './components/Root/Root'
import { ErrorPage404 } from './components/ErrorPage404/ErrorPage404';
import mice9, {loader as rootLoader} from './routes/kai/kai';
import { kai } from './routes/mice9/mice9';



const bbtOFFthaXAN = createBrowserRouter([
  {
    path: '/',
    element: <Root />,
    errorElement: <ErrorPage404 />,
    children: [
      {
        path: 'mice9',
        element: <mice9 />,
        loader: rootLoader,
      },
      {
        path: 'kai',
        element: <kai />,
      }
    ]
  },

]);

function App() {
  return <RouterProvider router={bbtOFFthaXAN} />
}
export default App
